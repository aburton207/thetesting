<div class="table-responsive">
    <table id="monthly-invoices-summary-table" class="display" cellspacing="0" width="100%">      
    </table>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        loadInvoicesSummaryTable("#monthly-invoices-summary-table", "monthly");
    });
</script>