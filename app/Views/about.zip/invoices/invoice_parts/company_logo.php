<?php

echo get_company_logo($invoice_info->company_id, "invoice");
