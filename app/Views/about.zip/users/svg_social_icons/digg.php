<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 97.361 97.361" style="enable-background:new 0 0 512 512" xml:space="preserve" class="icon-16"><g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M15.578,33.102H0v33.104h25.313V19.472h-9.735V33.102z M15.578,58.417H9.736V40.893h5.842V58.417z" fill="#ffffff" data-original="#000000" style="" class=""></path>
		<rect x="29.209" y="33.102" width="9.735" height="33.104" fill="#ffffff" data-original="#000000" style="" class=""></rect>
		<rect x="29.209" y="19.472" width="9.735" height="9.737" fill="#ffffff" data-original="#000000" style="" class=""></rect>
		<path d="M42.839,66.206h15.578V70.1H42.839v7.79h25.313V33.102H42.839V66.206z M52.577,40.893h5.841v17.524h-5.841V40.893z" fill="#ffffff" data-original="#000000" style="" class=""></path>
		<path d="M72.049,33.102v33.104h15.577V70.1H72.049v7.79h25.312V33.102H72.049z M87.626,58.417h-5.842V40.893h5.842V58.417z" fill="#ffffff" data-original="#000000" style="" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
</g></svg>