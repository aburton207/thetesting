<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 616 616" style="enable-background:new 0 0 512 512" xml:space="preserve" class="icon-16"><g>
<g xmlns="http://www.w3.org/2000/svg">
	<path d="M578.018,306.236c-15.868,3.658-31.218,5.272-45.035,5.272c-77.721,0-137.56-54.281-137.56-148.663   c0-46.262,17.887-70.318,43.178-70.318c24.062,0,40.104,21.588,40.104,65.386c0,24.902-6.67,52.194-11.595,68.34   c0,0,23.951,41.78,89.442,28.958c13.907-30.873,21.466-70.857,21.466-105.931C578.018,54.899,529.9,0,441.688,0   c-90.672,0-143.724,69.706-143.724,161.618c0,91.054,42.564,169.21,112.752,204.822c-29.514,59.039-67.068,111.044-106.235,150.229   c-71.062-85.902-135.302-200.504-161.662-424.141H37.982c48.437,372.464,192.781,491.06,230.946,513.833   c21.591,12.954,40.177,12.338,59.919,1.231c30.989-17.623,124.038-110.654,175.611-219.627c21.648-0.058,47.658-2.545,73.559-8.397   V306.236L578.018,306.236z" fill="#ffffff" data-original="#000000" style="" class=""></path>
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
</g></svg>