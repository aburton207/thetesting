<div class="text-center box mb20 dashboard-invalid-widget" style="height: 0;">
    <div class="box-content" style="vertical-align: middle"> 
        <div class="mb5"><span data-feather="slash" height="5rem" width="5rem" style="color: #d4d4d4;"></span></div>
        <div><?php echo app_lang("invalid_widget_access"); ?></div>        
    </div>
</div>