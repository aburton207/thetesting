<div class="card">
    <?php
    echo view("projects/comments/comment_form");

    echo view("projects/comments/comment_list");
    ?>
</div>