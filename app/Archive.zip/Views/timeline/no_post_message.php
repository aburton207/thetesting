<div class="text-center p30">
    <i data-feather="align-center" width="6rem" height="6rem"></i> <br />
    <?php
    echo app_lang("no_posts_to_show");
    ?>
</div>
