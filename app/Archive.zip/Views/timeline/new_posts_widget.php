<a href="<?php echo get_uri('timeline'); ?>" class="white-link" >
    <div class="card dashboard-icon-widget">
        <div class="card-body">
            <div class="widget-icon bg-primary">
                <i data-feather="send" class="icon"></i>
            </div>
            <div class="widget-details">
                <h1><?php echo $total; ?></h1>
                <span><?php echo app_lang("new_posts"); ?></span>
            </div>
        </div>
    </div>
</a>