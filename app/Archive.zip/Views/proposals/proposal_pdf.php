<?php 
echo $proposal_preview;
