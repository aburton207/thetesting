<?php if (get_setting("module_todo")) { ?>
    <li class="nav-item hidden-xs">
        <a href="<?php echo_uri('todo'); ?>" class=" nav-link dropdown-toggle"><i data-feather="check-circle"  class="icon"></i></a>
    </li>
<?php } ?>
